# Solana Program Release Checklist

Use this checklist after running the automated inspector.

## Configuration

- Confirm `Anchor.toml` exists or document the non-Anchor deploy process.
- Confirm the configured cluster is the intended target: localnet, devnet, testnet, or mainnet-beta.
- Confirm all program names in `[programs.<cluster>]` map to expected program IDs.
- Confirm each `declare_id!()` in `programs/*/src/lib.rs` matches the intended program ID.
- Confirm generated IDL metadata, if present, does not contradict the program ID.

## Build And Tests

- Run or request fresh output for the repository's canonical test command.
- For Anchor, prefer `anchor test` before release and `anchor build` before deployment.
- Confirm generated IDL files are fresh relative to source changes.
- Confirm generated client types, if used, are fresh relative to IDL changes.
- Confirm CI covers formatting, linting, unit tests, and integration tests where practical.

## Deploy Safety

- Confirm the deployer wallet and upgrade authority are intentionally chosen.
- Confirm any keypair files are local-only and never committed.
- Confirm no seed phrase, private key, RPC secret, or API token appears in docs, config, examples, logs, or generated artifacts.
- Confirm mainnet deployment steps include a dry-run/devnet rehearsal.
- Confirm post-deploy verification steps include fetching the program account and comparing deployed program ID.

## Governance

- If the program is upgradeable, document who controls upgrade authority.
- If governance/multisig controls upgrades, document the proposal or approval path.
- If authority is revoked, document when and why.

## Release Notes

- Include program ID, cluster, commit SHA, build command, test command, deploy command, IDL path, and known limitations.
- Include a rollback or upgrade plan for non-immutable programs.
- Include a short "do not share secrets" note for operators.
