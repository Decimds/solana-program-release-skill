#!/usr/bin/env python3
"""Read-only Solana/Anchor release readiness inspector.

The script intentionally avoids network calls and never reads keypair contents.
It summarizes local evidence so an agent can produce a release report.
"""

from __future__ import annotations

import argparse
import json
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any


PROGRAM_ID_RE = re.compile(r'declare_id!\s*\(\s*"([^"]+)"\s*\)')


@dataclass
class Finding:
    severity: str
    title: str
    evidence: str
    fix: str


def read_text(path: Path, limit: int = 1_000_000) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="replace")[:limit]
    except FileNotFoundError:
        return ""


def find_files(root: Path, patterns: list[str]) -> list[Path]:
    files: list[Path] = []
    for pattern in patterns:
        files.extend(root.glob(pattern))
    return sorted(set(p for p in files if p.is_file()))


def parse_anchor_programs(anchor_text: str) -> dict[str, dict[str, str]]:
    programs: dict[str, dict[str, str]] = {}
    current_cluster: str | None = None
    any_section_re = re.compile(r"^\s*\[([^\]]+)\]\s*$")
    kv_re = re.compile(r'^\s*([A-Za-z0-9_-]+)\s*=\s*"([^"]+)"\s*$')

    for line in anchor_text.splitlines():
        section = any_section_re.match(line)
        if section:
            section_name = section.group(1)
            if section_name.startswith("programs."):
                current_cluster = section_name.split(".", 1)[1]
                programs.setdefault(current_cluster, {})
            else:
                current_cluster = None
            continue
        if current_cluster:
            kv = kv_re.match(line)
            if kv:
                programs[current_cluster][kv.group(1)] = kv.group(2)
    return programs


def parse_idl(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001 - report parse failures as evidence
        return {"_parse_error": str(exc)}


def inspect(root: Path) -> dict[str, Any]:
    root = root.resolve()
    findings: list[Finding] = []

    anchor_toml = root / "Anchor.toml"
    cargo_toml = root / "Cargo.toml"
    anchor_text = read_text(anchor_toml)
    anchor_programs = parse_anchor_programs(anchor_text) if anchor_text else {}

    program_sources = find_files(root, ["programs/*/src/lib.rs", "programs/*/src/main.rs"])
    declare_ids = {}
    for source in program_sources:
        text = read_text(source)
        match = PROGRAM_ID_RE.search(text)
        if match:
            declare_ids[str(source.relative_to(root))] = match.group(1)

    idl_files = find_files(root, ["target/idl/*.json", "idl/*.json"])
    idl_programs = {}
    for idl in idl_files:
        data = parse_idl(idl)
        metadata = data.get("metadata") if isinstance(data, dict) else None
        address = None
        if isinstance(metadata, dict):
            address = metadata.get("address") or metadata.get("programId")
        idl_programs[str(idl.relative_to(root))] = {
            "name": data.get("name") if isinstance(data, dict) else None,
            "address": address,
            "parse_error": data.get("_parse_error") if isinstance(data, dict) else None,
        }

    deploy_artifacts = [str(p.relative_to(root)) for p in find_files(root, ["target/deploy/*.so"])]
    deploy_keypairs = [str(p.relative_to(root)) for p in find_files(root, ["target/deploy/*.json"])]
    tests = [str(p.relative_to(root)) for p in find_files(root, ["tests/**/*", "programs/*/tests/**/*"])]
    ci = [str(p.relative_to(root)) for p in find_files(root, [".github/workflows/*.yml", ".github/workflows/*.yaml"])]

    if not anchor_text:
        findings.append(
            Finding(
                "warning",
                "Anchor.toml not found",
                "No Anchor.toml was found at the repository root.",
                "Document the non-Anchor build/deploy flow or run the inspector from the Anchor workspace root.",
            )
        )
    if not cargo_toml.exists():
        findings.append(
            Finding(
                "blocker",
                "Cargo.toml not found",
                "No Cargo.toml was found at the repository root.",
                "Run from the Rust workspace root or add the missing manifest.",
            )
        )
    if not program_sources:
        findings.append(
            Finding(
                "blocker",
                "No program source files found",
                "No programs/*/src/lib.rs or main.rs files were found.",
                "Confirm this is a Solana program repo and document the source layout.",
            )
        )
    if program_sources and not declare_ids:
        findings.append(
            Finding(
                "warning",
                "No declare_id found",
                "Program source files exist, but no declare_id!(...) macro was detected.",
                "Confirm program IDs through the repository's framework or add explicit documentation.",
            )
        )
    if anchor_programs and declare_ids:
        configured_ids = {pid for cluster in anchor_programs.values() for pid in cluster.values()}
        declared_ids = set(declare_ids.values())
        if not configured_ids.intersection(declared_ids):
            findings.append(
                Finding(
                    "blocker",
                    "Anchor.toml program IDs do not match declare_id values",
                    f"Configured={sorted(configured_ids)}; declared={sorted(declared_ids)}",
                    "Update Anchor.toml or source declare_id! so the intended cluster program ID matches.",
                )
            )
    if not idl_files:
        findings.append(
            Finding(
                "warning",
                "No IDL artifacts found",
                "No target/idl/*.json or idl/*.json files were found.",
                "Run the build command and regenerate IDL artifacts before release.",
            )
        )
    if deploy_keypairs:
        findings.append(
            Finding(
                "warning",
                "Deploy keypair files present",
                f"Found {len(deploy_keypairs)} target/deploy JSON keypair artifact(s). Contents were not read.",
                "Ensure keypair artifacts are not committed and are handled as secrets.",
            )
        )
    if not tests:
        findings.append(
            Finding(
                "warning",
                "No tests found",
                "No tests/ or programs/*/tests/ files were found.",
                "Add or document release-blocking tests before deployment.",
            )
        )
    if not ci:
        findings.append(
            Finding(
                "info",
                "No GitHub Actions workflows found",
                "No .github/workflows YAML files were found.",
                "Consider adding CI for format, lint, build, and tests.",
            )
        )

    return {
        "root": str(root),
        "anchor_detected": bool(anchor_text),
        "anchor_programs": anchor_programs,
        "program_sources": [str(p.relative_to(root)) for p in program_sources],
        "declare_ids": declare_ids,
        "idl_programs": idl_programs,
        "deploy_artifacts": deploy_artifacts,
        "deploy_keypair_artifacts": deploy_keypairs,
        "tests": tests[:100],
        "ci": ci,
        "findings": [asdict(f) for f in findings],
    }


def to_markdown(report: dict[str, Any]) -> str:
    status = "Needs fixes" if any(f["severity"] == "blocker" for f in report["findings"]) else "Review needed"
    lines = [
        "# Solana Program Release Readiness Report",
        "",
        f"Status: {status}",
        "",
        "## Evidence Summary",
        "",
        f"- Repository: `{report['root']}`",
        f"- Anchor detected: `{report['anchor_detected']}`",
        f"- Program sources: `{len(report['program_sources'])}`",
        f"- IDL artifacts: `{len(report['idl_programs'])}`",
        f"- Deploy `.so` artifacts: `{len(report['deploy_artifacts'])}`",
        f"- Deploy keypair artifacts: `{len(report['deploy_keypair_artifacts'])}`",
        f"- Test files: `{len(report['tests'])}`",
        f"- CI workflows: `{len(report['ci'])}`",
        "",
        "## Program IDs",
        "",
    ]
    if report["anchor_programs"]:
        for cluster, programs in report["anchor_programs"].items():
            for name, pid in programs.items():
                lines.append(f"- Anchor `{cluster}` `{name}`: `{pid}`")
    if report["declare_ids"]:
        for file, pid in report["declare_ids"].items():
            lines.append(f"- Source `{file}`: `{pid}`")
    if not report["anchor_programs"] and not report["declare_ids"]:
        lines.append("- No program IDs detected.")

    lines.extend(["", "## Findings", ""])
    if report["findings"]:
        lines.append("| Severity | Finding | Evidence | Fix |")
        lines.append("|---|---|---|---|")
        for f in report["findings"]:
            lines.append(f"| {f['severity']} | {f['title']} | {f['evidence']} | {f['fix']} |")
    else:
        lines.append("- No static blockers detected. Human deploy/governance confirmation is still required.")

    lines.extend(
        [
            "",
            "## Human Confirmations Needed",
            "",
            "- Confirm target cluster and deployer wallet.",
            "- Confirm upgrade authority or governance owner.",
            "- Confirm fresh test/build output.",
            "- Confirm no secrets are committed or pasted into release notes.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Inspect Solana/Anchor release readiness evidence.")
    parser.add_argument("repo", help="Repository root to inspect")
    parser.add_argument("--out", help="Write Markdown report to this path")
    parser.add_argument("--json", help="Write JSON evidence to this path")
    args = parser.parse_args()

    report = inspect(Path(args.repo))
    markdown = to_markdown(report)
    if args.out:
        Path(args.out).write_text(markdown, encoding="utf-8")
    if args.json:
        Path(args.json).write_text(json.dumps(report, indent=2), encoding="utf-8")
    if not args.out:
        print(markdown)
    return 1 if any(f["severity"] == "blocker" for f in report["findings"]) else 0


if __name__ == "__main__":
    raise SystemExit(main())
