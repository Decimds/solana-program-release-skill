# Solana Program Release Readiness Report

## Status

Status: `Ready | Needs fixes | Blocked`

One-line summary:

## Evidence Summary

- Repository:
- Anchor detected:
- Program crates:
- Program IDs found:
- IDL artifacts:
- Test evidence:
- CI evidence:

## Blockers

| Severity | Finding | Evidence | Fix |
|---|---|---|---|
| Blocker |  |  |  |

## Configuration Consistency

- `Anchor.toml`:
- `declare_id!`:
- IDL metadata:
- Client types:
- Deployment docs:

## Build And Test Readiness

- Build command:
- Test command:
- CI checks:
- Missing proof:

## Deployment And Governance Confirmation

- Target cluster:
- Deployer wallet:
- Upgrade authority:
- Governance/multisig:
- Human confirmations needed:

## Copy-Paste Release Checklist

- [ ] Confirm program IDs match across config, source, IDL, and docs.
- [ ] Run fresh tests and attach output.
- [ ] Regenerate IDL/client artifacts if source changed.
- [ ] Confirm deploy authority and upgrade authority.
- [ ] Rehearse on devnet/testnet before mainnet.
- [ ] Verify deployed program account after deploy.
- [ ] Publish release notes with commit SHA and artifact paths.
